RosinSMP Logo Resource Pack - Minecraft 1.21.11

Custom logo glyph:
    U+E000  (Private Use Area)

In TAB/scoreboard text, insert the character:
    

This pack adds a custom bitmap font glyph. It does not replace vanilla textures.
Minecraft Java 1.21.11 uses resource pack version 75.0.
